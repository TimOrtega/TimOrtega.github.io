# Timothy Ortega — Engineering Portfolio

A static, responsive portfolio for GitHub Pages. No install or production build is required.

## Upload this update to GitHub

1. Unzip the download on your computer.
2. Open the Code tab of `TimOrtega/TimOrtega.github.io`.
3. Choose **Add file → Upload files**. Upload **index.html**, the entire **assets** folder, and the entire **projects** folder together. This replaces the homepage and adds the linked pages, styles, photos, video, models, and 3D viewer.
4. Commit to `main`. Keep Pages set to **Deploy from a branch → main → /(root)**.
5. Wait for deployment, then refresh. Do not upload the ZIP itself or nest everything inside a new folder.

The ZIP has its files directly at the root. The optional `.nojekyll`, README, and preview script can also be committed. There is no Sites hosting configuration or credential in this package.

```text
index.html
assets/
  site.css
  projects.css
  site.js
  images/
  models/
  video/
  vendor/
projects/
  ford-focus.html
  rocketry.html
  robotics.html
  fidget-spinner.html
  lighthouse.html
  bella-memorial.html
  clicker-game.html
```

## Preview locally

With Node.js installed, run `node preview.mjs` from this folder, then visit **http://127.0.0.1:4173**. Stop with Ctrl+C. The preview serves all pages and supports video range requests.

Opening index.html directly lets you read the site, but interactive 3D models require an HTTP server or GitHub Pages. The viewer explains this if opened through a file URL.

## Project pages

Seven clickable case studies cover the Ford Focus, rocketry drill jig, VEX High Stakes, fidget spinner, lighthouse, Bella memorial, and Java game. The homepage includes General and Software collections and category filters. Suspension CAD and autonomous UAVs remain interests.

All supplied photos and diagrams are included. Photos are sized for the web, with orientation preserved and metadata omitted; originals are untouched. The supplied silent robotics video is converted to H.264 MP4 for web playback.

Each CAD viewer has an explicit load button, rotation/zoom/pan controls, reset-view control, photo fallback, and GLB download. The jig and insert have separate viewers. Viewers show exported geometry, not CAD editing or an invented exploded animation.

## Edit

Edit the homepage in `index.html` and case-study text in `projects/*.html`. Shared design lives in `assets/site.css` and `assets/projects.css`. Interactions live in `assets/site.js`.

From project pages, use media paths beginning `../assets/`. From the homepage, use `assets/`. Match filenames and capitalization exactly. The About portrait remains a placeholder. Contact uses the resume email and LinkedIn; no phone number or full resume PDF is included.

## Dependencies and sources

Model Viewer 4.4.0 is bundled locally with its Apache 2.0 license under `assets/vendor/`. Supplied GLBs have no external texture/buffer dependencies and use no compression decoders. Interactive rendering requires JavaScript and WebGL. Photos and model downloads remain available if rendering fails.

Personal project content uses the supplied resume, photos, and descriptions. No new measured tolerances, operating pressures, performance improvements, or repair outcomes are invented. The engine photo is captioned as exposed camshafts. The vacuum-leak story describes a smoke test and ruptured diaphragm without inventing a more specific failed component.

- Model Viewer: https://modelviewer.dev/
- High Stakes context, also linked on the robotics page: https://kb.roboticseducation.org/hc/en-us/article_attachments/29449807522839
- GitHub Pages setup: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
